# Gesture-detection-using-mediapipe-and-randomforest-model-capturing-and-customing-your-own-labels

okey in this readme file you will be able to run this project on jupyter notebook.
you should have mediapipe installed and opencv.
after these installation with the file named capture best ,you have to change some labels of your own and capture about 100 data for each label the data will be stored in a csv file.
then after the csv file is created you have to train the csv file in the randtrain code and see the accuracy of your trained model.
then you have to run the realtime none file or best named file for real time prediction.
